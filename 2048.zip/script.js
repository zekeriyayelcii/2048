document.addEventListener("DOMContentLoaded", () => {
    const gridContainer = document.getElementById("grid-container");
    const scoreDisplay = document.getElementById("score");
    const messageDisplay = document.getElementById("message");
    const restartButton = document.getElementById("restartButton");

    let grid = [];
    let score = 0;
    let gameOver = false;

    function initializeGrid() {
        for (let i = 0; i < 4; i++) {
            grid[i] = [];
            for (let j = 0; j < 4; j++) {
                grid[i][j] = 0;
            }
        }
        addNumber();
        addNumber();
        updateGrid();
        updateScore();
    }

    function addNumber() {
        let options = [];
        for (let i = 0; i < 4; i++) {
            for (let j = 0; j < 4; j++) {
                if (grid[i][j] === 0) {
                    options.push({ x: i, y: j });
                }
            }
        }
        if (options.length > 0) {
            let spot = options[Math.floor(Math.random() * options.length)];
            let r = Math.random();
            grid[spot.x][spot.y] = r > 0.1 ? 2 : 4;
        }
    }

    function updateGrid() {
        gridContainer.innerHTML = "";
        for (let i = 0; i < 4; i++) {
            for (let j = 0; j < 4; j++) {
                let cell = document.createElement("div");
                cell.classList.add("grid-cell");
                cell.textContent = grid[i][j] === 0 ? "" : grid[i][j];
                cell.style.backgroundColor = getCellColor(grid[i][j]);
                gridContainer.appendChild(cell);
            }
        }
    }

    function getCellColor(value) {
        switch (value) {
            case 2: return "#eee4da";
            case 4: return "#ede0c8";
            case 8: return "#f2b179";
            case 16: return "#f59563";
            case 32: return "#f67c5f";
            case 64: return "#f65e3b";
            case 128: return "#edcf72";
            case 256: return "#edcc61";
            case 512: return "#edc850";
            case 1024: return "#edc53f";
            case 2048: return "#edc22e";
            default: return "#cdc1b4";
        }
    }

    function updateScore() {
        scoreDisplay.textContent = "Skor: " + score;
    }

    function slide(row) {
        let arr = row.filter(val => val);
        let missing = 4 - arr.length;
        let zeros = Array(missing).fill(0);
        arr = zeros.concat(arr);
        return arr;
    }

    function combine(row) {
        for (let i = 3; i >= 1; i--) {
            let a = row[i];
            let b = row[i - 1];
            if (a === b) {
                row[i] = a + b;
                score += row[i];
                row[i - 1] = 0;
            }
        }
        return row;
    }

    function moveDown() {
        for (let j = 0; j < 4; j++) {
            let row = [];
            for (let i = 0; i < 4; i++) {
                row.push(grid[i][j]);
            }
            row = slide(row);
            row = combine(row);
            row = slide(row);
            for (let i = 0; i < 4; i++) {
                grid[i][j] = row[i];
            }
        }
    }

    function moveUp() {
        for (let j = 0; j < 4; j++) {
            let row = [];
            for (let i = 3; i >= 0; i--) {
                row.push(grid[i][j]);
            }
            row = slide(row);
            row = combine(row);
            row = slide(row);
            for (let i = 3; i >= 0; i--) {
                grid[3 - i][j] = row[i];
            }
        }
    }

    function moveRight() {
        for (let i = 0; i < 4; i++) {
            let row = [...grid[i]];
            row = slide(row);
            row = combine(row);
            row = slide(row);
            grid[i] = row;
        }
    }

    function moveLeft() {
        for (let i = 0; i < 4; i++) {
            let row = [...grid[i]];
            row = slide(row.reverse()).reverse();
            row = combine(row);
            row = slide(row.reverse()).reverse();
            grid[i] = row;
        }
    }

    function checkGameOver() {
        for (let i = 0; i < 4; i++) {
            for (let j = 0; j < 4; j++) {
                if (grid[i][j] === 0) {
                    return false;
                }
                if (j !== 3 && grid[i][j] === grid[i][j + 1]) {
                    return false;
                }
                if (i !== 3 && grid[i][j] === grid[i + 1][j]) {
                    return false;
                }
            }
        }
        return true;
    }

    function checkGameWon() {
        for (let i = 0; i < 4; i++) {
            for (let j = 0; j < 4; j++) {
                if (grid[i][j] === 2048) {
                    return true;
                }
            }
        }
        return false;
    }

    function handleKeyPress(e) {
        if (gameOver) return;
        switch (e.key) {
            case "ArrowUp":
                moveUp();
                break;
            case "ArrowDown":
                moveDown();
                break;
            case "ArrowLeft":
                moveLeft();
                break;
            case "ArrowRight":
                moveRight();
                break;
            default:
                return;
        }
        addNumber();
        updateGrid();
        updateScore();
        if (checkGameWon()) {
            gameOver = true;
            messageDisplay.textContent = "Kazandınız!";
        }
        if (checkGameOver()) {
            gameOver = true;
            messageDisplay.textContent = "Oyun bitti!";
        }
    }

    function restartGame() {
        grid = [];
        score = 0;
        gameOver = false;
        messageDisplay.textContent = "";
        initializeGrid();
    }

    initializeGrid();
    document.addEventListener("keydown", handleKeyPress);
    restartButton.addEventListener("click", restartGame);
});
